#include <stdarg.h>
extern int vsprintf(char *sbuffer, char *fmt, va_list arg);
